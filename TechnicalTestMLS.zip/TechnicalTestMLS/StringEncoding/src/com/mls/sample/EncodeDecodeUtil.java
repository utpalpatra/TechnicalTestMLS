package com.mls.sample;

import org.apache.commons.lang.CharUtils;
import org.apache.commons.lang.StringUtils;

/**
 * Utilitity for Perform various encoding/decoding operation.
 * @author utpalkantipatra
 *
 */
public class EncodeDecodeUtil {
	
	private static final char FIRST_LOWERCASE_LETTER = 'a';    // the first lower case letter in the alphabet
	private static final char FIRST_UPPERCASE_LETTER = 'A';    // the first upper case letter in the alphabet
	private static final char LAST_LOWERCASE_LETTER = 'z';    // the last lower case letter in the alphabet
	private static final char LAST_UPPERCASE_LETTER = 'Z';    // the last upper case letter in the alphabet
	private static final int ALPHABETSIZE = 26;     // the number of letters in the alphabet

	/**
	 * Encode the given String based on the offset. If offset is 1
	 * If the offset is 1 then all 'a' letters are replaced with 'b', 'b' with 'c', etc.
	 * If the offset is -1 then all 'a' letters are replaced with 'z', 'b' with 'a', etc. All non-character symbols are not modified.
	 * @param offset
	 * @param original
	 * @return
	 */
	public static String encode(int offset, String original) {
		if (StringUtils.isBlank(original) || offset == 0) {
			return original;
		}

		StringBuilder encodedValue = new StringBuilder();
		for(int i=0; i<original.length(); i++) {
			char charAtIndexPosition = original.charAt(i);
			if (Character.isLetter(charAtIndexPosition)) {
				processEncoding(offset, encodedValue, charAtIndexPosition);
			} else {
				encodedValue.append(Character.toString(charAtIndexPosition));
			}
		}
		return encodedValue.toString();

	}

	/**
	 * Perform encoding if a character is a letter.
	 * @param offset
	 * @param encodedValue
	 * @param charAtIndexPosition
	 */
	private static void processEncoding(int offset, StringBuilder encodedValue, char charAtIndexPosition) {
		if (CharUtils.isAsciiAlphaLower(charAtIndexPosition)) {
			if (offset < 0) {
				encodedValue.append(Character.toString((char) (LAST_LOWERCASE_LETTER - (LAST_LOWERCASE_LETTER - charAtIndexPosition - offset) % ALPHABETSIZE))); 
			} else {
				encodedValue.append(Character.toString((char) (((charAtIndexPosition - FIRST_LOWERCASE_LETTER + offset) % ALPHABETSIZE) + FIRST_LOWERCASE_LETTER))); 
			}
		} else if (CharUtils.isAsciiAlphaUpper(charAtIndexPosition)) {
			if (offset < 0) {
				encodedValue.append(Character.toString((char) (LAST_UPPERCASE_LETTER - (LAST_UPPERCASE_LETTER - charAtIndexPosition - offset) % ALPHABETSIZE))); 
			} else {
				encodedValue.append(Character.toString((char) (((charAtIndexPosition - FIRST_UPPERCASE_LETTER + offset) % ALPHABETSIZE) + FIRST_UPPERCASE_LETTER)));
			}
		}
	}
}
